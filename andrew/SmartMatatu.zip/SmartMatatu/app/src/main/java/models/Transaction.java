package com.smartmatatu.kenya.models;

import java.util.Date;

public class Transaction {
    private String id;
    private String matatuId;
    private String conductorId;
    private double amount;
    private Date timestamp;
    private String passengerCount;
    private TransactionType type;
    private String routeId;

    public enum TransactionType {
        CASH, DIGITAL, EXPENSE
    }

    public Transaction() {}

    public Transaction(String id, String matatuId, String conductorId,
                       double amount, String passengerCount, TransactionType type, String routeId) {
        this.id = id;
        this.matatuId = matatuId;
        this.conductorId = conductorId;
        this.amount = amount;
        this.timestamp = new Date();
        this.passengerCount = passengerCount;
        this.type = type;
        this.routeId = routeId;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getMatatuId() { return matatuId; }
    public void setMatatuId(String matatuId) { this.matatuId = matatuId; }

    public String getConductorId() { return conductorId; }
    public void setConductorId(String conductorId) { this.conductorId = conductorId; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public Date getTimestamp() { return timestamp; }
    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }

    public String getPassengerCount() { return passengerCount; }
    public void setPassengerCount(String passengerCount) { this.passengerCount = passengerCount; }

    public TransactionType getType() { return type; }
    public void setType(TransactionType type) { this.type = type; }

    public String getRouteId() { return routeId; }
    public void setRouteId(String routeId) { this.routeId = routeId; }
}