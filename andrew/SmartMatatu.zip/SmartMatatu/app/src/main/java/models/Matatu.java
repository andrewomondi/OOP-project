package com.smartmatatu.kenya.models;

import java.util.Date;

public class Matatu {
    private String id;
    private String registrationNumber;
    private String routeId;
    private String driverId;
    private String conductorId;
    private int capacity;
    private boolean isActive;
    private Date lastMaintenance;
    private double currentLocationLat;
    private double currentLocationLng;

    public Matatu() {}

    public Matatu(String id, String registrationNumber, String routeId,
                  String driverId, String conductorId, int capacity) {
        this.id = id;
        this.registrationNumber = registrationNumber;
        this.routeId = routeId;
        this.driverId = driverId;
        this.conductorId = conductorId;
        this.capacity = capacity;
        this.isActive = true;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getRegistrationNumber() { return registrationNumber; }
    public void setRegistrationNumber(String registrationNumber) { this.registrationNumber = registrationNumber; }

    public String getRouteId() { return routeId; }
    public void setRouteId(String routeId) { this.routeId = routeId; }

    public String getDriverId() { return driverId; }
    public void setDriverId(String driverId) { this.driverId = driverId; }

    public String getConductorId() { return conductorId; }
    public void setConductorId(String conductorId) { this.conductorId = conductorId; }

    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public Date getLastMaintenance() { return lastMaintenance; }
    public void setLastMaintenance(Date lastMaintenance) { this.lastMaintenance = lastMaintenance; }

    public double getCurrentLocationLat() { return currentLocationLat; }
    public void setCurrentLocationLat(double currentLocationLat) { this.currentLocationLat = currentLocationLat; }

    public double getCurrentLocationLng() { return currentLocationLng; }
    public void setCurrentLocationLng(double currentLocationLng) { this.currentLocationLng = currentLocationLng; }
}