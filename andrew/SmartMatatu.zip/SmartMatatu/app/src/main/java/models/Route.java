package com.smartmatatu.kenya.models;

import java.util.List;

public class Route {
    private String id;
    private String name;
    private String startPoint;
    private String endPoint;
    private List<String> stops;
    private double distance; // in kilometers
    private double estimatedTime; // in minutes
    private double fare;

    public Route() {}

    public Route(String id, String name, String startPoint, String endPoint,
                 List<String> stops, double distance, double estimatedTime, double fare) {
        this.id = id;
        this.name = name;
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.stops = stops;
        this.distance = distance;
        this.estimatedTime = estimatedTime;
        this.fare = fare;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getStartPoint() { return startPoint; }
    public void setStartPoint(String startPoint) { this.startPoint = startPoint; }

    public String getEndPoint() { return endPoint; }
    public void setEndPoint(String endPoint) { this.endPoint = endPoint; }

    public List<String> getStops() { return stops; }
    public void setStops(List<String> stops) { this.stops = stops; }

    public double getDistance() { return distance; }
    public void setDistance(double distance) { this.distance = distance; }

    public double getEstimatedTime() { return estimatedTime; }
    public void setEstimatedTime(double estimatedTime) { this.estimatedTime = estimatedTime; }

    public double getFare() { return fare; }
    public void setFare(double fare) { this.fare = fare; }
}
