package com.example.smartmatatu;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_main);  // COMMENT OUT
        setContentView(android.R.layout.simple_list_item_1);  // Use system layout
    }
}