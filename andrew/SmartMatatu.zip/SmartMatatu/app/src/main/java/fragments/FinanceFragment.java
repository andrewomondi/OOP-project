package com.smartmatatu.kenya.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.smartmatatu.kenya.R;
import com.smartmatatu.kenya.adapters.TransactionAdapter;
import com.smartmatatu.kenya.models.Transaction;
import java.util.ArrayList;
import java.util.List;

public class FinanceFragment extends Fragment {

    private TextView tvTodayRevenue, tvWeekRevenue;
    private Button btnAddTransaction;
    private RecyclerView recyclerViewTransactions;
    private TransactionAdapter transactionAdapter;

    public FinanceFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_finance, container, false);

        initializeViews(view);
        setupRecyclerView();
        setupClickListeners();
        loadFinanceData();

        return view;
    }

    private void initializeViews(View view) {
        tvTodayRevenue = view.findViewById(R.id.tvTodayRevenue);
        tvWeekRevenue = view.findViewById(R.id.tvWeekRevenue);
        btnAddTransaction = view.findViewById(R.id.btnAddTransaction);
        recyclerViewTransactions = view.findViewById(R.id.recyclerViewTransactions);
    }

    private void setupRecyclerView() {
        transactionAdapter = new TransactionAdapter(getSampleTransactions());
        recyclerViewTransactions.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewTransactions.setAdapter(transactionAdapter);
    }

    private void setupClickListeners() {
        btnAddTransaction.setOnClickListener(v -> showAddTransactionDialog());
    }

    private void loadFinanceData() {
        // Simulate loading data
        tvTodayRevenue.setText("KSh 32,150");
        tvWeekRevenue.setText("KSh 215,780");

        // In real app: fetch from Firestore/API
    }

    private void showAddTransactionDialog() {
        // Implementation for adding new transaction
        // This would show a dialog or start a new activity
    }

    private List<Transaction> getSampleTransactions() {
        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction("1", "KCD 123A", "CON001", 4500, "45", Transaction.TransactionType.CASH, "ROUTE001"));
        transactions.add(new Transaction("2", "KBC 456B", "CON002", 3200, "32", Transaction.TransactionType.DIGITAL, "ROUTE002"));
        transactions.add(new Transaction("3", "KCD 123A", "CON001", 2800, "28", Transaction.TransactionType.CASH, "ROUTE001"));
        return transactions;
    }
}