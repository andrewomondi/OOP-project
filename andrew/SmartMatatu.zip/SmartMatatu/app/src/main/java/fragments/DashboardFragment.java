package com.smartmatatu.kenya.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.smartmatatu.kenya.R;

public class DashboardFragment extends Fragment {

    private TextView tvUserName, tvActiveVehicles, tvTodayRevenue;
    private Button btnViewMap, btnAddTransaction, btnManageRoutes;

    public DashboardFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        initializeViews(view);
        setupClickListeners();
        loadDashboardData();

        return view;
    }

    private void initializeViews(View view) {
        tvUserName = view.findViewById(R.id.tvUserName);
        tvActiveVehicles = view.findViewById(R.id.tvActiveVehicles);
        tvTodayRevenue = view.findViewById(R.id.tvTodayRevenue);

        btnViewMap = view.findViewById(R.id.btnViewMap);
        btnAddTransaction = view.findViewById(R.id.btnAddTransaction);
        btnManageRoutes = view.findViewById(R.id.btnManageRoutes);
    }

    private void setupClickListeners() {
        btnViewMap.setOnClickListener(v -> {
            // Navigate to map fragment
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).findViewById(R.id.viewPager).post(() ->
                        ((androidx.viewpager2.widget.ViewPager2)
                                ((MainActivity) getActivity()).findViewById(R.id.viewPager)).setCurrentItem(1));
            }
        });

        btnAddTransaction.setOnClickListener(v -> {
            // Navigate to finance fragment
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).findViewById(R.id.viewPager).post(() ->
                        ((androidx.viewpager2.widget.ViewPager2)
                                ((MainActivity) getActivity()).findViewById(R.id.viewPager)).setCurrentItem(2));
            }
        });

        btnManageRoutes.setOnClickListener(v -> {
            // Show route management dialog or activity
            // Implementation for route management
        });
    }

    private void loadDashboardData() {
        // Simulate loading data
        tvUserName.setText("John Doe (Manager)");
        tvActiveVehicles.setText("8");
        tvTodayRevenue.setText("KSh 32,150");

        // In real app, this would fetch from Firestore/API
        // fetchDashboardDataFromServer();
    }
}